/*
* COPYRIGHT (c) 2017 Obigo Inc. All rights reserved.
*
* This software is covered by the license agreement between
* the end user and Obigo Inc.,and may be
* used and copied only in accordance with the terms of the
* said agreement.
*
* Obigo Inc. assumes no responsibility or
* liability for any errors or inaccuracies in this software,
* or any consequential, incidental or indirect damage arising
* out of the use of the software.
*
*/
'use strict';
var path = require('path'),
    os = require('os');

module.exports = {
    ROOT : __dirname,
    BIN : path.join(__dirname, 'bin'),
    TEMP : os.platform() == 'win32' ? path.join(process.env.TEMP, 'oat_'+(new Date()).getTime()) : path.sep+path.join(process.env.HOME, '.config', 'Oat', 'temp', 'oat_'+(new Date()).getTime()),
    TEMPLATES : path.join(__dirname, 'templates'),
    ASSETS : path.join(__dirname, 'assets'),
    WIZARD : path.join(__dirname, 'assets', 'authentication', 'wizard'),
    DEFAULT_CERT : path.join(__dirname, 'assets', '.default-certificates'),
    CERT : os.platform() == 'win32' ? path.join(process.env.APPDATA, 'Obigo', '.certificates-store') : path.sep+path.join(process.env.HOME, '.config', 'Obigo', '.certificates-store'),
    OBIGO : os.platform() == 'win32' ? path.join(process.env.APPDATA, 'Obigo') : path.sep+path.join(process.env.HOME, '.config', 'Obigo')
}