#!/usr/bin/env node

/*
* COPYRIGHT (c) 2017 Obigo Inc. All rights reserved.
*
* This software is covered by the license agreement between
* the end user and Obigo Inc.,and may be
* used and copied only in accordance with the terms of the
* said agreement.
*
* Obigo Inc. assumes no responsibility or
* liability for any errors or inaccuracies in this software,
* or any consequential, incidental or indirect damage arising
* out of the use of the software.
*
*/

'use strict';

process.env.NODE_PATH = __dirname + '/../node_modules/';

var commander = require('commander'),
    co = require('co'),
    util = require('util'),
    fs = require('fs'),
    fse = require('fs-extra'),
    path = require('path'),
    cliSpinners = require('cli-spinners'),
    ora = require('ora'),
    config = require('./config');

~function init(){
    createTemp();
}();

commander
    .version(require('./package').version)
    .usage('<Command> [Options] [Args]');

commander
    .command('cm')
    .description('Manage certificates.')
    .option('-l, --list', 'List certificates.')
    .option('-i, --init', 'Install the default certificate')
    .action(function (options) {
        co(function*(){
            var spinner = ora({text : "signning", spinner : cliSpinners.simpleDotsScrolling})
            try{
                var res = yield require('./lib/commands/cm')(options);
                if(res)
                    spinner.succeed(res);
            }catch(e){
                spinner.fail(util.format('cm Error: %s', e));
            }
            removeTemp();
        })
    });

commander
    .command('sign <certificate-name> <target-dir>')
    .option('-l, --level <access-level>', 'The level of access to the API(access-level ex: level-0)')
    .description('Sign the files in the target directory with a certificate.')
    .action(function (certificateName, targetDir, options) {
        var targetDir = pathRelativeToAbsolute(targetDir);
        co(function*(){
            var spinner = ora({text : "signning", spinner : cliSpinners.simpleDotsScrolling}).start();
            try{
               var res = yield require('./lib/commands/signature')(certificateName, path.normalize(targetDir), options);
               spinner.succeed(res);
            }catch(e){
                spinner.fail(util.format('sign Error: %s', e));
            }
            removeTemp();
            spinner.stop();
        })
    });

commander
    .command('encrypt <target-dir>')
    .description('Encrypt app files.')
    .action(function (targetDir){
        targetDir = pathRelativeToAbsolute(targetDir);
        co(function*(){
            var spinner = ora({text : "encrypting", spinner : cliSpinners.simpleDotsScrolling}).start();
            try{
                var count = yield require('./lib/commands/encrypt')(targetDir);
                spinner.succeed(util.format('Number of files encrypted : %s (files)', count));
            }catch(e){
                spinner.fail(util.format('encrypt Error: %s', e));
            }
            removeTemp();
            spinner.stop();
        })
    })

commander
    .command('pack <working-directory>')
    .option('-o, --outpath <path>', 'Set the location of the wgt file')
    .option('-a, --appname <name>', 'Set the name of the wgt file')
    .description('Compressed into a .wgt file.')
    .action(function(workingDir, options){
        workingDir = pathRelativeToAbsolute(workingDir);
        co(function*(){
            var spinner = ora({text : "packaging", spinner : cliSpinners.simpleDotsScrolling}).start();
            try{
                var res = yield require('./lib/commands/pack')(workingDir, options);
                spinner.succeed(res);
            }catch(e){
                spinner.fail(util.format('pack Error: %s', e));
            }
            removeTemp();
            spinner.stop();
        })
    })

commander
    .command('push <local-file-path> <remote-dir-path>')
    .option('-s, --simulator', 'set the simulator as the target')
    .option('-t, --target <userid:password@host>', 'set the device as the target')
    .description('Transfer the file to the remote site.(default : simulator)')
    .action(function(localFilePath, remoteFilePath, options){
        localFilePath = pathRelativeToAbsolute(localFilePath);
        co(function*(){
            var spinner = ora({text : "pushing", spinner : cliSpinners.simpleDotsScrolling}).start();
            try{
                var res = yield require('./lib/commands/push')(localFilePath, remoteFilePath, options);
                spinner.succeed(res);
            }catch(e){
                spinner.fail(util.format('push Error: %s', e));
            }
            removeTemp();
            spinner.stop();
        })
    })

commander
    .command('install <app-file>')
    .option('-s, --simulator', 'set the simulator as the target')
    .option('-t, --target <userid:password@host>', 'set the device as the target')
    .description('Install an APP on an simulator or connected device.')
    .action(function(appFile, options){
        co(function*(){
            var spinner = ora({text : "installing", spinner : cliSpinners.simpleDotsScrolling}).start();
            try{
                var res = yield require('./lib/commands/install')(appFile, options);
                spinner.succeed(res);
            }catch(e){
                spinner.fail(util.format('install Error: %s', e));
            }
            removeTemp();
            spinner.stop();
        })
    })

commander
    .command('uninstall <app-id>')
    .option('-s, --simulator', 'set the simulator as the target')
    .option('-t, --target <userid:password@host>', 'set the device as the target')
    .description('Uninstall an APP on an simulator or connected device.')
    .action(function(appID, options){
        co(function*(){
            var spinner = ora({text : "uninstalling", spinner : cliSpinners.simpleDotsScrolling}).start();
            try{
                var res = yield require('./lib/commands/uninstall')(appID, options);
                spinner.succeed(res);
            }catch(e){
                spinner.fail(util.format('uninstall Error: %s', e));
            }
            removeTemp();
            spinner.stop();
        })
    })

// TODO: ...


// parse -> argv
commander.parse(process.argv);

// if no arguments where passed
if (!commander.args.length) {
    // print help
    commander.help();
}

function createTemp(){
    fse.ensureDirSync(config.TEMP);
}

function removeTemp(){
    fse.removeSync(config.TEMP);
}

function pathRelativeToAbsolute(tempPath){
    if(path.isAbsolute(tempPath)){
        return tempPath;
    }
    return path.join(process.cwd(), tempPath);
}